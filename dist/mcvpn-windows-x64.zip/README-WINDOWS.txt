mcvpn for Windows
=================
1. Extract ALL files from the zip into a normal folder (mcvpn.exe and
   wintun.dll must sit side by side). Do not run the exe from inside the zip.
2. Run mcvpn.exe and accept the UAC prompt (needed to create the VPN adapter).
3. Paste the line printed by the server installer
       mcvpn://<token>@<server-ip>:25565
   into the SERVER field (leave TOKEN empty) and press CONNECT.
   (Or type server + token separately; stray spaces are ignored.)
4. Check: open any "what is my IP" site - it must show the server's IP.

If it does not connect: press "Show log" -> "Copy log" and send the text.
The same log is written to mcvpn.log next to mcvpn.exe.
